alert('CV is downloaded successfully.');
